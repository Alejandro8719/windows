            ===============================================================================================
           | # About:                                                                                      |
           |                                                                                               |
           | - W10 LTSB 2015 Digital License Activation Script                                             |
           |   Activate the Windows 10 LTSB 2015 permanently with digital License.                         |
           |   [gatherosstate.exe in this package have 1/66 AV Detections Score on virus total]            |
           |                                                                                               |
            ===============================================================================================
           | # Remarks:                                                                                    |
           |                                                                                               |
           | - This script does not install any files in your system.                                      |
           |                                                                                               |
           | - For Successful Instant Activation,The Windows Update Service and Internet Must be Enabled.  |
           |   If you are running it anyway then system will auto-activate later when you enable the       |
           |   Windows update service and Internet.                                                        |
           |                                                                                               |
           | - Use of VPN, and privacy, anti spy tools, privacy-based hosts and firewall's rules           |
           |   may cause (due to blocking of some MS servers) problems in successful Activation.           |
           |                                                                                               |
           | - You may see a Error about 'Blocked key' in activation process.                              |
           |   This blocked key error cause is actually not the any key or this script                     |
           |   but its either the issues i mentioned above or MS server problem.                           |
           |                                                                                               |
           | - In same hardware, after activation, if user reinstall the same windows edition then         |
           |   'Retail (Consumer)' version of Windows 10 will auto activate at first online contact.       |
           |   but                                                                                         |
           |   In case of 'VL (Business)' version of Windows 10, User will have to insert that windows     |
           |   edition productkey to activate the system You can insert the product key manually           |
           |   or you can use tool's option "Insert Product key".It saves the ticket generating process.   |
           |                                                                                               |
            ===============================================================================================
           | # Windows 10 Preactivate:                                                                     |
           |                                                                                               |
           | - To preactivate the system during installation,Do the following things.                      |
           |   Use option No. 6 in script and extract the $OEM$ Folder to Desktop. Now copy this $OEM$     |
           |   Folder to "sources" folder in the installation media.                                       |
           |   The directory will appear like this. iso/usb: \sources\$OEM$\                               |
           |   Now use this iso/usb to install Windows 10 and it'll auto activate at first online contact. |
           |                                                                                               |
            ===============================================================================================
           | # Supported Windows 10 Editions:                                                              |
           |                                                                                               |
           | EnterpriseS (LTSB) 2015 and (N)                                                               |
           |                                                                                               |
            ===============================================================================================
           | # Credits:                                                                                    |
           |                                                                                               |
           | s1ave77       - Original Author of Digital License Generation without KMS or predecessor      |
           |                 install/upgrade                                                               |
           |                                                                                               |
           | mephistooo2   - Repacking s1ave77's earlier cmd version in 'KMS-Digital-Activation_Suite'     |
           |                                                                                               |
           | WindowsAddict - Repacking mephistooo2's Repack to make a clean, separate, and improved        |
           |                 W10 Digital License Activation Script                                         |
           |                                                                                               |
           | rpo           - Providing Great support in correction and improvements in this script         |      
           |                                                                                               |
            ===============================================================================================
           | # Homepage:                                                                                   |
           |                                                                                               |
           | (For Questions, problems, Error reports, suggestions, and criticism etc.)                     |
           | https://www.nsaneforums.com/topic/316668-w10-digital-license-activation-script/               |
           |                                                                                               |
            ===============================================================================================